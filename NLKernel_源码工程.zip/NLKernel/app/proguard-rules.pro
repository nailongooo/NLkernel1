# =====================================================================
# proguard-rules.pro — 代码混淆规则
# 防止混淆导致反射调用失败
# =====================================================================

# 保留所有 Model 类（JSON 反序列化时需要字段名不变）
-keep class com.nlkernel.app.model.** { *; }

# 保留 OkHttp（内部使用反射）
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# 保留 BlurView
-keep class eightbitlab.com.blurview.** { *; }

# 保留 Parcelable
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# 保留枚举
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# 调试时保留行号信息，便于定位崩溃
-keepattributes SourceFile,LineNumberTable
