package com.nlkernel.app.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.nlkernel.app.BuildConfig;
import com.nlkernel.app.R;
import com.nlkernel.app.databinding.FragmentAboutBinding;

/**
 * AboutFragment — 关于页
 *
 * 显示内容：
 *   - 应用名称和版本号
 *   - 应用描述
 *   - 作者 Telegram 联系方式（@NL78991）
 *   - 官方频道（@NLkernel888）
 *   - 免责声明
 *
 * 交互：
 *   - 点击 TG 用户名/频道：尝试跳转到 Telegram App
 *     若未安装 Telegram，则复制到剪贴板
 *   - 长按复制 TG 用户名
 */
public class AboutFragment extends Fragment {

    /** Telegram 作者用户名 */
    private static final String TG_AUTHOR = "@NL78991";
    /** Telegram 频道 */
    private static final String TG_CHANNEL = "@NLkernel888";

    /** Telegram Deep Link 格式（去掉 @ 号） */
    private static final String TG_AUTHOR_URL = "https://t.me/NL78991";
    private static final String TG_CHANNEL_URL = "https://t.me/NLkernel888";

    private FragmentAboutBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentAboutBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // ---- 版本号 ----
        // BuildConfig.VERSION_NAME 在编译时自动注入，来自 build.gradle 的 versionName
        String versionText = getString(R.string.about_version, BuildConfig.VERSION_NAME);
        binding.tvVersion.setText(versionText);

        // ---- 作者 TG 用户名 ----
        binding.tvTgAuthor.setText(TG_AUTHOR);
        binding.cardTgAuthor.setOnClickListener(v -> openTelegram(TG_AUTHOR_URL, TG_AUTHOR));
        // 长按复制
        binding.cardTgAuthor.setOnLongClickListener(v -> {
            copyToClipboard(TG_AUTHOR);
            return true; // 消费事件，不触发点击
        });

        // ---- 官方频道 ----
        binding.tvTgChannel.setText(TG_CHANNEL);
        binding.cardTgChannel.setOnClickListener(v -> openTelegram(TG_CHANNEL_URL, TG_CHANNEL));
        binding.cardTgChannel.setOnLongClickListener(v -> {
            copyToClipboard(TG_CHANNEL);
            return true;
        });
    }

    /**
     * 尝试通过 Telegram Deep Link 打开 Telegram App 跳转到指定用户/频道。
     * 若设备未安装 Telegram，回退到复制到剪贴板。
     *
     * @param url      Telegram 链接（https://t.me/xxx）
     * @param handle   用户名文字（显示在 Toast 中）
     */
    private void openTelegram(String url, String handle) {
        if (getContext() == null) return;

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

        // 检查系统中是否有 App 可以处理此 Intent
        if (intent.resolveActivity(requireContext().getPackageManager()) != null) {
            // 有 Telegram（或浏览器）可以打开
            startActivity(intent);
        } else {
            // 无法打开：复制到剪贴板并提示用户
            copyToClipboard(handle);
            Toast.makeText(getContext(),
                    "未检测到 Telegram，已复制：" + handle,
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 将文本复制到系统剪贴板。
     *
     * @param text 要复制的文本
     */
    private void copyToClipboard(String text) {
        if (getContext() == null) return;

        ClipboardManager clipboard = (ClipboardManager)
                requireContext().getSystemService(Context.CLIPBOARD_SERVICE);

        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText("NLKernel TG", text);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(getContext(),
                    getString(R.string.about_copy_tg),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
