package com.nlkernel.app.model;

/**
 * KernelScript — 内核脚本数据模型
 *
 * 代表从服务器拉取的一个 .sh 脚本文件。
 * 包含文件名、完整下载 URL、文件大小（可选）等信息。
 */
public class KernelScript {

    /** 脚本文件名，如 "optimize.sh" */
    private final String filename;

    /** 完整下载 URL，如 "http://nlkernel.nailong.link/neihe/optimize.sh" */
    private final String downloadUrl;

    /**
     * 文件大小（字节），可能为 -1 表示未知。
     * 某些服务器的目录列表不包含文件大小信息。
     */
    private long fileSize;

    /**
     * 最后修改时间（字符串形式，从目录列表中解析）。
     * 例如 "2024-01-15 10:30" 或 null。
     */
    private String lastModified;

    /** 下载状态枚举 */
    public enum DownloadState {
        IDLE,        // 未下载
        DOWNLOADING, // 下载中
        EXECUTING,   // 执行中
        SUCCESS,     // 执行成功
        FAILED       // 失败
    }

    /** 当前下载/执行状态 */
    private DownloadState state = DownloadState.IDLE;

    /**
     * 构造方法：最小化构造，只需文件名和下载 URL
     *
     * @param filename    脚本文件名（不含路径），如 "boost_cpu.sh"
     * @param downloadUrl 完整下载 URL
     */
    public KernelScript(String filename, String downloadUrl) {
        this.filename = filename;
        this.downloadUrl = downloadUrl;
        this.fileSize = -1;
        this.lastModified = null;
    }

    /**
     * 获取脚本的"显示名称"：
     * 去掉 .sh 后缀，下划线替换为空格，首字母大写。
     * 例如："boost_cpu.sh" → "Boost Cpu"
     *
     * @return 用户友好的显示名称
     */
    public String getDisplayName() {
        // 移除 .sh 后缀
        String name = filename.endsWith(".sh")
                ? filename.substring(0, filename.length() - 3)
                : filename;
        // 下划线和连字符替换为空格
        name = name.replace('_', ' ').replace('-', ' ');
        // 每个单词首字母大写
        StringBuilder result = new StringBuilder();
        for (String word : name.split(" ")) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        return result.toString().trim();
    }

    /**
     * 获取格式化的文件大小字符串。
     * 例如：1024 → "1.0 KB"，1048576 → "1.0 MB"
     *
     * @return 可读的文件大小字符串，未知时返回 "未知大小"
     */
    public String getFormattedSize() {
        if (fileSize <= 0) return "未知大小";
        if (fileSize < 1024) return fileSize + " B";
        if (fileSize < 1024 * 1024) return String.format("%.1f KB", fileSize / 1024.0);
        return String.format("%.1f MB", fileSize / (1024.0 * 1024));
    }

    // ----------------------------------------------------------------
    // Getters & Setters
    // ----------------------------------------------------------------

    public String getFilename() { return filename; }

    public String getDownloadUrl() { return downloadUrl; }

    public long getFileSize() { return fileSize; }

    public void setFileSize(long fileSize) { this.fileSize = fileSize; }

    public String getLastModified() { return lastModified; }

    public void setLastModified(String lastModified) { this.lastModified = lastModified; }

    public DownloadState getState() { return state; }

    public void setState(DownloadState state) { this.state = state; }

    @Override
    public String toString() {
        return "KernelScript{filename='" + filename + "', url='" + downloadUrl + "'}";
    }
}
