package com.nlkernel.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.nlkernel.app.R;
import com.nlkernel.app.model.KernelScript;

import java.util.ArrayList;
import java.util.List;

/**
 * KernelScriptAdapter — 内核脚本列表适配器
 *
 * 将 KernelScript 列表渲染为 RecyclerView 中的卡片列表。
 * 每个卡片显示：文件名、大小、下载/执行状态、操作按钮。
 *
 * ViewHolder 复用机制：
 *   RecyclerView 只创建屏幕可见数量 + 少量缓存的 ViewHolder，
 *   滚动时重复使用（onBindViewHolder 负责更新数据），
 *   避免大量实例化造成的内存和性能问题。
 */
public class KernelScriptAdapter extends RecyclerView.Adapter<KernelScriptAdapter.ViewHolder> {

    private final Context context;
    /** 脚本数据列表 */
    private List<KernelScript> scripts;

    /**
     * 下载/执行按钮点击回调接口
     */
    public interface OnScriptClickListener {
        /**
         * 用户点击某个脚本的"下载并执行"按钮时回调
         *
         * @param script   被点击的脚本对象
         * @param position 列表中的位置索引
         */
        void onDownloadClick(KernelScript script, int position);
    }

    private OnScriptClickListener clickListener;

    /**
     * 构造方法
     *
     * @param context Android 上下文
     */
    public KernelScriptAdapter(Context context) {
        this.context = context;
        this.scripts = new ArrayList<>();
    }

    /** 设置点击监听器 */
    public void setOnScriptClickListener(OnScriptClickListener listener) {
        this.clickListener = listener;
    }

    /**
     * 更新列表数据（整体替换）
     *
     * @param newScripts 新的脚本列表
     */
    public void setScripts(List<KernelScript> newScripts) {
        this.scripts = new ArrayList<>(newScripts);
        // notifyDataSetChanged() 会重新绑定所有可见项
        // 生产环境中建议改用 DiffUtil 以支持局部刷新动画
        notifyDataSetChanged();
    }

    /**
     * 更新单个脚本的状态（下载进度/执行结果），触发该 item 的局部刷新。
     *
     * @param position 需要刷新的列表位置
     */
    public void notifyItemStateChanged(int position) {
        if (position >= 0 && position < scripts.size()) {
            notifyItemChanged(position);
        }
    }

    // ====================================================================
    // RecyclerView.Adapter 必须实现的方法
    // ====================================================================

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 将 item_kernel_script.xml 布局 inflate 为 View
        View view = LayoutInflater.from(context).inflate(
                R.layout.item_kernel_script, parent, false
        );
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        KernelScript script = scripts.get(position);

        // 绑定基本信息
        holder.tvFilename.setText(script.getDisplayName());
        holder.tvFilenameRaw.setText(script.getFilename());
        holder.tvFileSize.setText(script.getFormattedSize());

        // 根据当前状态设置 UI
        updateItemState(holder, script);

        // 设置点击事件（使用 getAdapterPosition() 防止 RecyclerView 动画时 position 错位）
        holder.btnDownload.setOnClickListener(v -> {
            int adapterPos = holder.getAdapterPosition();
            if (adapterPos == RecyclerView.NO_ID) return; // 防御性检查
            if (clickListener != null) {
                KernelScript clickedScript = scripts.get(adapterPos);
                // 只有在 IDLE 或 FAILED 状态才允许点击
                if (clickedScript.getState() == KernelScript.DownloadState.IDLE
                        || clickedScript.getState() == KernelScript.DownloadState.FAILED) {
                    clickListener.onDownloadClick(clickedScript, adapterPos);
                }
            }
        });

        // 整个 CardView 的点击（与按钮相同效果）
        holder.cardView.setOnClickListener(v -> holder.btnDownload.performClick());
    }

    /**
     * 根据脚本的下载/执行状态更新 ViewHolder 的 UI 显示。
     *
     * @param holder ViewHolder
     * @param script 对应的数据
     */
    private void updateItemState(ViewHolder holder, KernelScript script) {
        switch (script.getState()) {
            case IDLE:
                // 空闲：显示下载按钮，隐藏进度条
                holder.btnDownload.setVisibility(View.VISIBLE);
                holder.btnDownload.setEnabled(true);
                holder.btnDownload.setText(R.string.kernel_download);
                holder.progressBar.setVisibility(View.GONE);
                holder.tvStatus.setVisibility(View.GONE);
                holder.ivStatus.setVisibility(View.GONE);
                break;

            case DOWNLOADING:
                // 下载中：显示进度条，按钮变为"下载中…"不可点击
                holder.btnDownload.setVisibility(View.VISIBLE);
                holder.btnDownload.setEnabled(false);
                holder.btnDownload.setText(R.string.kernel_downloading);
                holder.progressBar.setVisibility(View.VISIBLE);
                holder.progressBar.setIndeterminate(true);
                holder.tvStatus.setVisibility(View.GONE);
                holder.ivStatus.setVisibility(View.GONE);
                break;

            case EXECUTING:
                // 执行中：进度条无限循环，提示执行中
                holder.btnDownload.setVisibility(View.VISIBLE);
                holder.btnDownload.setEnabled(false);
                holder.btnDownload.setText(R.string.kernel_executing);
                holder.progressBar.setVisibility(View.VISIBLE);
                holder.progressBar.setIndeterminate(true);
                holder.tvStatus.setVisibility(View.GONE);
                holder.ivStatus.setVisibility(View.GONE);
                break;

            case SUCCESS:
                // 成功：显示绿色状态标签，按钮可再次点击
                holder.btnDownload.setVisibility(View.VISIBLE);
                holder.btnDownload.setEnabled(true);
                holder.btnDownload.setText(R.string.kernel_download);
                holder.progressBar.setVisibility(View.GONE);
                holder.tvStatus.setVisibility(View.VISIBLE);
                holder.tvStatus.setText(R.string.kernel_success);
                holder.tvStatus.setTextColor(0xFF34C759); // 成功绿
                holder.ivStatus.setVisibility(View.VISIBLE);
                holder.ivStatus.setColorFilter(0xFF34C759);
                break;

            case FAILED:
                // 失败：显示红色状态标签，按钮可重试
                holder.btnDownload.setVisibility(View.VISIBLE);
                holder.btnDownload.setEnabled(true);
                holder.btnDownload.setText(R.string.kernel_download);
                holder.progressBar.setVisibility(View.GONE);
                holder.tvStatus.setVisibility(View.VISIBLE);
                holder.tvStatus.setText(R.string.kernel_failed);
                holder.tvStatus.setTextColor(0xFFFF3B30); // 错误红
                holder.ivStatus.setVisibility(View.VISIBLE);
                holder.ivStatus.setColorFilter(0xFFFF3B30);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return scripts != null ? scripts.size() : 0;
    }

    // ====================================================================
    // ViewHolder 内部类
    // ====================================================================

    /**
     * ViewHolder — 持有列表项各个子视图的引用。
     *
     * 每次 onBindViewHolder 调用时直接使用这些引用，
     * 避免重复调用 findViewById（耗费 CPU 时间）。
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final MaterialCardView cardView;  // 卡片容器
        final TextView tvFilename;        // 脚本显示名称（处理后的可读名）
        final TextView tvFilenameRaw;     // 原始文件名（.sh）
        final TextView tvFileSize;        // 文件大小
        final MaterialButton btnDownload; // 下载/执行按钮
        final ProgressBar progressBar;    // 下载/执行进度条
        final TextView tvStatus;          // 状态文字（成功/失败）
        final ImageView ivStatus;         // 状态图标

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_kernel_item);
            tvFilename = itemView.findViewById(R.id.tv_script_name);
            tvFilenameRaw = itemView.findViewById(R.id.tv_script_filename);
            tvFileSize = itemView.findViewById(R.id.tv_script_size);
            btnDownload = itemView.findViewById(R.id.btn_download);
            progressBar = itemView.findViewById(R.id.progress_bar);
            tvStatus = itemView.findViewById(R.id.tv_status);
            ivStatus = itemView.findViewById(R.id.iv_status);
        }
    }
}
