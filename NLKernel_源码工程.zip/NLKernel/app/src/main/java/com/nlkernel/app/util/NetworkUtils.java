package com.nlkernel.app.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.nlkernel.app.model.KernelScript;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * NetworkUtils — 网络请求与文件下载工具类
 *
 * 功能：
 *   1. 检测网络连接状态
 *   2. 拉取服务器目录列表（Apache/Nginx HTML 目录索引）
 *   3. 解析 HTML 提取 .sh 文件名
 *   4. 下载脚本文件到临时目录
 *
 * 注意：
 *   所有网络方法均为同步阻塞，必须在子线程调用。
 *   服务器使用 HTTP（非 HTTPS），已通过 network_security_config.xml 允许。
 */
public class NetworkUtils {

    private static final String TAG = "NLKernel_Network";

    /** 内核脚本目录 URL（HTTP，服务器返回 Apache/Nginx 目录列表 HTML） */
    public static final String BASE_URL = "http://nlkernel.nailong.link/neihe/";

    /** 单个 OkHttpClient 实例（线程安全，全局复用） */
    private static OkHttpClient httpClient;

    /** 下载进度回调接口 */
    public interface DownloadProgressCallback {
        /**
         * 进度更新回调
         * @param progress 0~100 的整数百分比，-1 表示进度未知
         */
        void onProgress(int progress);
    }

    // ====================================================================
    // OkHttpClient 单例
    // ====================================================================

    /**
     * 获取 OkHttpClient 单例（懒加载，线程安全）。
     * 配置：30 秒连接超时、60 秒读取超时。
     */
    private static synchronized OkHttpClient getClient() {
        if (httpClient == null) {
            httpClient = new OkHttpClient.Builder()
                    .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                    .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .retryOnConnectionFailure(true) // 失败时自动重试一次
                    .build();
        }
        return httpClient;
    }

    // ====================================================================
    // 网络状态检测
    // ====================================================================

    /**
     * 检测当前网络是否可用（有网络连接且网络已连接）。
     *
     * @param context Android 上下文
     * @return true = 网络可用，false = 无网络
     */
    public static boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;

            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null && activeNetwork.isConnected();

        } catch (Exception e) {
            Log.w(TAG, "检测网络状态失败: " + e.getMessage());
            return false;
        }
    }

    // ====================================================================
    // 目录列表拉取与解析
    // ====================================================================

    /**
     * 拉取服务器目录列表，解析其中所有 .sh 文件，返回 KernelScript 列表。
     *
     * 原理：
     *   访问 BASE_URL，服务器返回 Apache/Nginx 标准目录索引 HTML，
     *   格式如：<a href="boost_cpu.sh">boost_cpu.sh</a>
     *   通过正则表达式提取所有 .sh 文件的 href 属性值。
     *
     * @return 解析到的脚本列表，失败时返回空列表
     * @throws IOException 网络请求失败时抛出
     */
    public static List<KernelScript> fetchKernelScriptList() throws IOException {
        List<KernelScript> scripts = new ArrayList<>();

        Log.i(TAG, "开始拉取脚本列表: " + BASE_URL);

        Request request = new Request.Builder()
                .url(BASE_URL)
                .addHeader("User-Agent", "NLKernel/1.0 Android")
                .build();

        try (Response response = getClient().newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("服务器返回错误码: " + response.code());
            }

            String html = response.body() != null ? response.body().string() : "";
            Log.d(TAG, "收到目录列表 HTML，长度: " + html.length() + " chars");

            // 解析 HTML，提取 .sh 文件链接
            scripts = parseShFilesFromHtml(html);
            Log.i(TAG, "解析到 " + scripts.size() + " 个脚本文件");
        }

        return scripts;
    }

    /**
     * 从 Apache/Nginx 目录列表 HTML 中提取所有 .sh 文件。
     *
     * 兼容多种服务器的目录列表格式：
     *   Apache: <a href="script.sh">script.sh</a>
     *   Nginx:  <a href="script.sh">script.sh</a>
     *   自定义: 只要有 href="*.sh" 即可识别
     *
     * @param html 服务器返回的完整 HTML 字符串
     * @return 解析到的 KernelScript 列表
     */
    private static List<KernelScript> parseShFilesFromHtml(String html) {
        List<KernelScript> scripts = new ArrayList<>();

        /*
         * 正则表达式说明：
         * href=["']([^"']*\.sh)["']
         *   - href= 匹配属性名
         *   - ["'] 匹配单引号或双引号
         *   - ([^"']*\.sh) 捕获组：不含引号的任意字符 + ".sh" 结尾
         *   - ["'] 闭合引号
         * CASE_INSENSITIVE：大小写不敏感（href= 或 HREF= 都匹配）
         */
        Pattern pattern = Pattern.compile(
                "href=[\"']([^\"']*\\.sh)[\"']",
                Pattern.CASE_INSENSITIVE
        );

        Matcher matcher = pattern.matcher(html);
        while (matcher.find()) {
            String href = matcher.group(1);

            // 过滤：只处理纯文件名或相对路径的 .sh 文件
            // 跳过以 "/" 开头的绝对路径（可能是父目录链接）
            // 跳过以 "?" 开头的查询参数
            if (href == null || href.startsWith("/") || href.startsWith("?")
                    || href.startsWith("..")) {
                continue;
            }

            // 提取纯文件名（处理相对路径如 "subdir/script.sh"）
            String filename = href.contains("/")
                    ? href.substring(href.lastIndexOf('/') + 1)
                    : href;

            if (filename.isEmpty()) continue;

            // 构建完整下载 URL
            String downloadUrl = BASE_URL + filename;

            // 避免重复（某些目录列表会有重复 href）
            boolean duplicate = false;
            for (KernelScript s : scripts) {
                if (s.getFilename().equals(filename)) {
                    duplicate = true;
                    break;
                }
            }

            if (!duplicate) {
                scripts.add(new KernelScript(filename, downloadUrl));
                Log.d(TAG, "找到脚本: " + filename + " -> " + downloadUrl);
            }
        }

        return scripts;
    }

    // ====================================================================
    // 文件下载
    // ====================================================================

    /**
     * 下载脚本文件到 App 私有临时目录。
     *
     * 使用 App 私有目录（/data/data/com.nlkernel.app/cache/scripts/）作为临时存储，
     * 下载完成后由 RootUtils 将其复制到 /data/adb/NLkernel/。
     *
     * 选择 App 私有目录的原因：
     *   1. 无需任何存储权限（Android 11+ 废除 WRITE_EXTERNAL_STORAGE）
     *   2. 始终可写，不受存储管理政策影响
     *   3. 比 /sdcard 更可靠（某些 ROM 限制 /sdcard 的某些操作）
     *
     * @param context          Android 上下文（用于获取缓存目录）
     * @param downloadUrl      完整下载 URL
     * @param filename         保存的文件名
     * @param progressCallback 下载进度回调（可为 null）
     * @return 下载后的临时文件对象，失败时返回 null
     * @throws IOException 下载失败时抛出
     */
    public static File downloadScript(
            Context context,
            String downloadUrl,
            String filename,
            DownloadProgressCallback progressCallback
    ) throws IOException {

        Log.i(TAG, "开始下载脚本: " + downloadUrl);

        // 创建临时存储目录
        File tempDir = new File(context.getCacheDir(), "scripts");
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }

        // 临时文件路径
        File tempFile = new File(tempDir, filename);

        // 使用 HttpURLConnection 下载（支持进度回调，比 OkHttp 更直接）
        HttpURLConnection connection = null;
        InputStream inputStream = null;
        OutputStream outputStream = null;

        try {
            URL url = new URL(downloadUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(30_000);  // 30 秒连接超时
            connection.setReadTimeout(60_000);     // 60 秒读取超时
            connection.setRequestProperty("User-Agent", "NLKernel/1.0 Android");
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new IOException("下载失败，HTTP " + responseCode);
            }

            // 获取文件大小（用于计算进度）
            long contentLength = connection.getContentLengthLong();
            Log.d(TAG, "文件大小: " + contentLength + " bytes");

            inputStream = connection.getInputStream();
            outputStream = new FileOutputStream(tempFile);

            // 分块读写，每次 8KB
            byte[] buffer = new byte[8192];
            long downloadedBytes = 0;
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
                downloadedBytes += bytesRead;

                // 回调进度
                if (progressCallback != null && contentLength > 0) {
                    int progress = (int) (downloadedBytes * 100 / contentLength);
                    progressCallback.onProgress(progress);
                } else if (progressCallback != null) {
                    progressCallback.onProgress(-1); // 进度未知
                }
            }

            outputStream.flush();
            Log.i(TAG, "下载完成: " + tempFile.getAbsolutePath()
                    + "，大小: " + downloadedBytes + " bytes");

            return tempFile;

        } catch (IOException e) {
            // 下载失败时清理残留文件
            if (tempFile.exists()) {
                tempFile.delete();
            }
            throw e;
        } finally {
            // 关闭所有流
            if (inputStream != null) {
                try { inputStream.close(); } catch (IOException ignored) {}
            }
            if (outputStream != null) {
                try { outputStream.close(); } catch (IOException ignored) {}
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
