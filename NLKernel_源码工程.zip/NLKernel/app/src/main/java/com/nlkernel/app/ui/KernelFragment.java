package com.nlkernel.app.ui;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nlkernel.app.R;
import com.nlkernel.app.adapter.KernelScriptAdapter;
import com.nlkernel.app.databinding.FragmentKernelBinding;
import com.nlkernel.app.model.KernelScript;
import com.nlkernel.app.util.NetworkUtils;
import com.nlkernel.app.util.RootUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * KernelFragment — 内核脚本管理页
 *
 * 功能流程：
 *   1. Fragment 可见时，检测网络 + Root 权限
 *   2. 从 http://nlkernel.nailong.link/neihe/ 拉取脚本目录列表
 *   3. 解析 .sh 文件列表，渲染到 RecyclerView
 *   4. 用户点击某脚本 → 弹出确认对话框
 *   5. 用户确认 → 后台下载 → 移动到 /data/adb/NLkernel/ → chmod 777 → 执行
 *   6. 执行结果以 Toast + 状态标签形式展示
 *
 * 线程安全注意：
 *   - 所有网络/文件/Root 操作在 executor 子线程执行
 *   - UI 更新通过 mainHandler.post() 切回主线程
 *   - 避免使用 AsyncTask（Android 11 已废弃）
 */
public class KernelFragment extends Fragment {

    private static final String TAG = "NLKernel_Kernel";

    private FragmentKernelBinding binding;
    private KernelScriptAdapter adapter;

    /** 单线程执行器：确保下载/执行操作串行，避免并发冲突 */
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /** 主线程 Handler */
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    /** 脚本列表是否已加载（避免切换 Tab 时重复网络请求） */
    private boolean listLoaded = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentKernelBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 初始化 RecyclerView
        setupRecyclerView();

        // 下拉刷新：强制重新拉取列表
        binding.swipeRefresh.setOnRefreshListener(() -> {
            listLoaded = false;
            loadScriptList();
        });
        binding.swipeRefresh.setColorSchemeColors(0xFF007AFF);
        binding.swipeRefresh.setProgressBackgroundColorSchemeColor(0xFFFFFFFF);

        // 刷新按钮
        binding.btnRefresh.setOnClickListener(v -> {
            listLoaded = false;
            loadScriptList();
        });

        // 首次加载
        if (!listLoaded) {
            loadScriptList();
        }
    }

    /**
     * 初始化 RecyclerView 和 Adapter。
     */
    private void setupRecyclerView() {
        adapter = new KernelScriptAdapter(requireContext());

        // 设置点击回调：用户点击下载按钮时触发
        adapter.setOnScriptClickListener((script, position) -> {
            showConfirmDialog(script, position);
        });

        binding.rvScripts.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvScripts.setAdapter(adapter);

        // 禁用 RecyclerView 的默认过渡动画（防止列表刷新时的闪烁）
        binding.rvScripts.setItemAnimator(null);
    }

    /**
     * 显示执行确认对话框。
     *
     * 安全设计：
     *   执行 Root 脚本风险较高，弹出对话框要求用户主动确认，
     *   显示文件名和目标路径，确保用户知情。
     *
     * @param script   待执行脚本
     * @param position 列表位置
     */
    private void showConfirmDialog(KernelScript script, int position) {
        if (!isAdded() || getContext() == null) return;

        String message = getString(R.string.kernel_dialog_msg, script.getFilename());

        new MaterialAlertDialogBuilder(requireContext(), R.style.Dialog_NLKernel)
                .setTitle(R.string.kernel_dialog_title)
                .setMessage(message)
                .setPositiveButton(R.string.kernel_dialog_confirm, (dialog, which) -> {
                    // 用户确认：开始下载并执行
                    downloadAndExecute(script, position);
                })
                .setNegativeButton(R.string.kernel_dialog_cancel, null)
                .show();
    }

    /**
     * 从服务器拉取脚本列表（主入口）。
     *
     * 前置检查：
     *   1. 网络是否可用
     *   2. Root 是否已获取（提示性检查，不强制阻止加载列表）
     */
    private void loadScriptList() {
        if (getContext() == null) return;

        // UI 进入加载状态
        showLoadingState();

        // 检查网络
        if (!NetworkUtils.isNetworkAvailable(requireContext())) {
            showErrorState(getString(R.string.error_network));
            binding.swipeRefresh.setRefreshing(false);
            return;
        }

        // 后台拉取列表
        executor.execute(() -> {
            try {
                Log.i(TAG, "开始拉取脚本列表...");
                List<KernelScript> scripts = NetworkUtils.fetchKernelScriptList();

                mainHandler.post(() -> {
                    if (!isAdded() || binding == null) return;
                    binding.swipeRefresh.setRefreshing(false);

                    if (scripts.isEmpty()) {
                        showEmptyState();
                    } else {
                        showContentState(scripts);
                        listLoaded = true;
                        Log.i(TAG, "脚本列表加载完成，共 " + scripts.size() + " 个");
                    }
                });

            } catch (IOException e) {
                Log.e(TAG, "拉取脚本列表失败: " + e.getMessage());
                mainHandler.post(() -> {
                    if (!isAdded() || binding == null) return;
                    binding.swipeRefresh.setRefreshing(false);
                    showErrorState(getString(R.string.kernel_error));
                });
            }
        });
    }

    /**
     * 下载脚本并以 Root 权限执行（核心业务逻辑）。
     *
     * 完整流程：
     *   下载 → 临时保存 → Root 复制到 /data/adb/NLkernel/ → chmod 777 → 执行
     *
     * @param script   要执行的脚本
     * @param position 列表位置（用于更新 UI 状态）
     */
    private void downloadAndExecute(KernelScript script, final int position) {
        if (getContext() == null) return;

        // 先检测 Root（异步，但为确保流程正确性，在这里先做同步检测提示）
        // 实际执行仍在子线程，此处仅是提前告知用户
        executor.execute(() -> {
            if (!RootUtils.isRooted()) {
                mainHandler.post(() -> {
                    if (!isAdded()) return;
                    Toast.makeText(getContext(), R.string.kernel_no_root, Toast.LENGTH_LONG).show();
                });
                return;
            }

            // ---- 步骤 1：更新 UI 为下载中状态 ----
            script.setState(KernelScript.DownloadState.DOWNLOADING);
            mainHandler.post(() -> {
                if (!isAdded() || binding == null) return;
                adapter.notifyItemStateChanged(position);
            });

            // ---- 步骤 2：下载脚本到临时目录 ----
            File tempFile = null;
            try {
                Log.i(TAG, "开始下载: " + script.getDownloadUrl());
                tempFile = NetworkUtils.downloadScript(
                        requireContext(),
                        script.getDownloadUrl(),
                        script.getFilename(),
                        progress -> {
                            // 进度回调（此处仅日志，UI 显示的是无限进度条）
                            Log.v(TAG, "下载进度: " + progress + "%");
                        }
                );
                Log.i(TAG, "下载完成，临时文件: " + tempFile.getAbsolutePath());

            } catch (IOException e) {
                Log.e(TAG, "下载失败: " + e.getMessage());
                final String errorMsg = "下载失败: " + e.getMessage();

                script.setState(KernelScript.DownloadState.FAILED);
                mainHandler.post(() -> {
                    if (!isAdded() || binding == null) return;
                    adapter.notifyItemStateChanged(position);
                    Toast.makeText(getContext(), errorMsg, Toast.LENGTH_LONG).show();
                });
                return;
            }

            // ---- 步骤 3：更新 UI 为执行中状态 ----
            script.setState(KernelScript.DownloadState.EXECUTING);
            mainHandler.post(() -> {
                if (!isAdded() || binding == null) return;
                adapter.notifyItemStateChanged(position);
            });

            // ---- 步骤 4：移动文件、赋权、执行 ----
            Log.i(TAG, "开始执行脚本（Root）...");
            RootUtils.ExecuteResult result = RootUtils.moveAndExecuteScript(
                    tempFile.getAbsolutePath(),
                    script.getFilename()
            );

            // ---- 步骤 5：清理临时文件 ----
            if (tempFile.exists()) {
                tempFile.delete();
                Log.d(TAG, "已清理临时文件");
            }

            // ---- 步骤 6：根据结果更新 UI ----
            final boolean success = result.success;
            final String output = result.output;
            final String error = result.error;

            if (success) {
                script.setState(KernelScript.DownloadState.SUCCESS);
            } else {
                script.setState(KernelScript.DownloadState.FAILED);
            }

            mainHandler.post(() -> {
                if (!isAdded() || binding == null) return;
                adapter.notifyItemStateChanged(position);

                if (success) {
                    // 显示执行成功 Toast
                    String msg = getString(R.string.kernel_success)
                            + (output.isEmpty() ? "" : "\n" + output);
                    Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
                } else {
                    // 显示失败详情
                    String msg = getString(R.string.kernel_failed)
                            + "\n" + (error.isEmpty() ? output : error);
                    showResultDialog(script.getFilename(), false, msg);
                }
            });
        });
    }

    /**
     * 显示执行结果对话框（失败时展示详细错误信息）。
     *
     * @param filename 脚本文件名
     * @param success  是否成功
     * @param detail   详细输出
     */
    private void showResultDialog(String filename, boolean success, String detail) {
        if (!isAdded() || getContext() == null) return;

        new MaterialAlertDialogBuilder(requireContext(), R.style.Dialog_NLKernel)
                .setTitle(success ? "执行成功" : "执行失败")
                .setMessage(filename + "\n\n" + detail)
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    // ====================================================================
    // UI 状态管理
    // ====================================================================

    /** 显示加载状态（进度条 + 隐藏其他） */
    private void showLoadingState() {
        binding.progressLoading.setVisibility(View.VISIBLE);
        binding.rvScripts.setVisibility(View.GONE);
        binding.layoutEmpty.setVisibility(View.GONE);
        binding.layoutError.setVisibility(View.GONE);
        binding.tvSubtitle.setText(R.string.kernel_loading);
    }

    /** 显示内容列表 */
    private void showContentState(List<KernelScript> scripts) {
        adapter.setScripts(scripts);
        binding.progressLoading.setVisibility(View.GONE);
        binding.rvScripts.setVisibility(View.VISIBLE);
        binding.layoutEmpty.setVisibility(View.GONE);
        binding.layoutError.setVisibility(View.GONE);
        binding.tvSubtitle.setText(scripts.size() + " 个可用脚本");
    }

    /** 显示空状态（服务器无脚本） */
    private void showEmptyState() {
        binding.progressLoading.setVisibility(View.GONE);
        binding.rvScripts.setVisibility(View.GONE);
        binding.layoutEmpty.setVisibility(View.VISIBLE);
        binding.layoutError.setVisibility(View.GONE);
        binding.tvSubtitle.setText(R.string.kernel_empty);
    }

    /** 显示错误状态（网络失败等） */
    private void showErrorState(String errorMsg) {
        binding.progressLoading.setVisibility(View.GONE);
        binding.rvScripts.setVisibility(View.GONE);
        binding.layoutEmpty.setVisibility(View.GONE);
        binding.layoutError.setVisibility(View.VISIBLE);
        binding.tvError.setText(errorMsg);
        binding.tvSubtitle.setText(R.string.kernel_error);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
