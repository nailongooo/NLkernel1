package com.nlkernel.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.nlkernel.app.databinding.ActivityMainBinding;
import com.nlkernel.app.ui.AboutFragment;
import com.nlkernel.app.ui.HomeFragment;
import com.nlkernel.app.ui.KernelFragment;

/**
 * MainActivity — 应用唯一 Activity
 *
 * 职责：
 *   1. 设置沉浸式全屏（内容延伸到状态栏/导航栏区域）
 *   2. 托管 3 个 Fragment（主页、内核、关于）
 *   3. 驱动底部玻璃导航栏的切换逻辑
 *   4. 处理系统 WindowInsets（针对不同机型的刘海/打孔/圆角屏）
 *
 * Fragment 管理策略：
 *   采用"预加载 + 显示/隐藏"策略（add + show/hide），
 *   而非"替换"（replace）策略，保证切换 Tab 时不重复加载数据，
 *   Fragment 状态（滚动位置、数据）不会丢失。
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    // 3 个 Fragment 实例（Application 生命周期内复用）
    private HomeFragment homeFragment;
    private KernelFragment kernelFragment;
    private AboutFragment aboutFragment;

    /** 当前显示的 Fragment */
    private Fragment activeFragment;

    /** 当前选中的 Tab 索引（0=主页, 1=内核, 2=关于） */
    private int currentTabIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ----------------------------------------------------------------
        // 1. 沉浸式全屏设置
        // ----------------------------------------------------------------

        // 让 Window 内容绘制到系统栏（状态栏/导航栏）区域
        // WindowCompat.setDecorFitsSystemWindows(false) 是 API 21+ 的推荐方式
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        // 状态栏和导航栏背景设为透明
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        // 亮色背景下，状态栏图标使用深色（黑色）
        // Android 6.0+ 支持亮色状态栏图标
        View decorView = getWindow().getDecorView();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR // 状态栏深色图标
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR // 导航栏深色图标（API 26+）
            );
        }

        // ----------------------------------------------------------------
        // 2. ViewBinding 初始化
        // ----------------------------------------------------------------
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // ----------------------------------------------------------------
        // 3. 处理 WindowInsets（适配各品牌异形屏）
        // ----------------------------------------------------------------
        setupWindowInsets();

        // ----------------------------------------------------------------
        // 4. 初始化 Fragment
        // ----------------------------------------------------------------
        initFragments(savedInstanceState);

        // ----------------------------------------------------------------
        // 5. 设置底部玻璃导航栏点击事件
        // ----------------------------------------------------------------
        setupNavBar();
    }

    /**
     * 处理 WindowInsets，让布局内容正确避开刘海、打孔屏、系统导航条。
     *
     * 策略：
     *   - 顶部 Padding：主内容区域增加状态栏高度的 Padding，
     *     避免内容被状态栏遮挡（Fragment 内容区）
     *   - 底部：由 Glass NavBar 本身处理（NavBar 内部预留 Padding）
     */
    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.fragmentContainer, (view, insets) -> {
            // 获取系统栏（状态栏 + 导航栏）的 Insets
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int bottomInset = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;

            // Fragment 容器增加顶部 Padding（避开状态栏）
            view.setPadding(0, topInset, 0, 0);

            return insets;
        });

        // 底部导航栏也需要感知 Insets，在内部增加合适的底部 Padding
        ViewCompat.setOnApplyWindowInsetsListener(binding.bottomNavContainer, (view, insets) -> {
            int bottomInset = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            // 增加底部 Padding 以避开系统导航条（手势导航/三键导航）
            view.setPadding(0, 0, 0, bottomInset);
            return insets;
        });
    }

    /**
     * 初始化 3 个 Fragment 并添加到 FragmentManager。
     * 恢复重建时（如屏幕旋转）从 savedInstanceState 恢复已有 Fragment，
     * 避免重复添加导致叠加显示的 Bug。
     *
     * @param savedInstanceState Activity 重建时的保存状态
     */
    private void initFragments(Bundle savedInstanceState) {
        FragmentManager fm = getSupportFragmentManager();

        if (savedInstanceState == null) {
            // 首次创建：实例化并添加所有 Fragment
            homeFragment = new HomeFragment();
            kernelFragment = new KernelFragment();
            aboutFragment = new AboutFragment();

            fm.beginTransaction()
                    .add(R.id.fragment_container, homeFragment, "HOME")
                    .add(R.id.fragment_container, kernelFragment, "KERNEL")
                    .add(R.id.fragment_container, aboutFragment, "ABOUT")
                    .hide(kernelFragment)  // 初始隐藏内核 Fragment
                    .hide(aboutFragment)  // 初始隐藏关于 Fragment
                    .commit();

            activeFragment = homeFragment;
        } else {
            // Activity 重建：从 FragmentManager 中找回已有 Fragment（避免重复添加）
            homeFragment = (HomeFragment) fm.findFragmentByTag("HOME");
            kernelFragment = (KernelFragment) fm.findFragmentByTag("KERNEL");
            aboutFragment = (AboutFragment) fm.findFragmentByTag("ABOUT");

            // 根据保存的 tab 索引恢复选中状态
            currentTabIndex = savedInstanceState.getInt("tab_index", 0);
            activeFragment = getFragmentByIndex(currentTabIndex);
        }
    }

    /**
     * 设置底部导航栏各按钮的点击事件。
     */
    private void setupNavBar() {
        binding.navItemHome.setOnClickListener(v -> switchTab(0));
        binding.navItemKernel.setOnClickListener(v -> switchTab(1));
        binding.navItemAbout.setOnClickListener(v -> switchTab(2));

        // 初始化选中态
        updateNavUI(0);
    }

    /**
     * 切换到指定 Tab（核心导航逻辑）。
     * 同一 Tab 连续点击不重复切换（防止无意义的 FragmentTransaction）。
     *
     * @param tabIndex 目标 Tab 索引（0=主页, 1=内核, 2=关于）
     */
    private void switchTab(int tabIndex) {
        if (tabIndex == currentTabIndex) return;

        Fragment targetFragment = getFragmentByIndex(tabIndex);
        if (targetFragment == null) return;

        // 使用 FragmentTransaction 隐藏当前、显示目标
        // TRANSIT_FRAGMENT_FADE 添加淡入淡出过渡动画
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        transaction.hide(activeFragment);
        transaction.show(targetFragment);
        transaction.commit();

        activeFragment = targetFragment;
        currentTabIndex = tabIndex;

        // 更新导航栏 UI 选中状态
        updateNavUI(tabIndex);
    }

    /**
     * 根据索引获取对应 Fragment。
     *
     * @param index Tab 索引
     * @return 对应 Fragment，索引无效时返回 homeFragment
     */
    private Fragment getFragmentByIndex(int index) {
        switch (index) {
            case 1: return kernelFragment;
            case 2: return aboutFragment;
            default: return homeFragment;
        }
    }

    /**
     * 更新底部导航栏的选中/未选中状态。
     * 通过 setSelected() 触发 ColorStateList 和 Drawable Selector 的状态切换。
     *
     * @param selectedIndex 当前选中的 Tab 索引
     */
    private void updateNavUI(int selectedIndex) {
        // 重置所有导航项为未选中
        binding.navItemHome.setSelected(false);
        binding.navItemKernel.setSelected(false);
        binding.navItemAbout.setSelected(false);

        // 设置目标导航项为选中
        switch (selectedIndex) {
            case 0:
                binding.navItemHome.setSelected(true);
                break;
            case 1:
                binding.navItemKernel.setSelected(true);
                break;
            case 2:
                binding.navItemAbout.setSelected(true);
                break;
        }
    }

    /**
     * 保存当前 Tab 索引（Activity 重建时恢复）。
     * 例如：屏幕旋转、开发者选项"不保留活动"等场景。
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("tab_index", currentTabIndex);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null; // 防止内存泄漏
    }
}
