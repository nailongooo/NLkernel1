package com.nlkernel.app;

import android.app.Application;
import androidx.multidex.MultiDex;
import android.content.Context;

/**
 * NLKernelApp — 应用程序全局类
 *
 * 继承 Application，在整个应用生命周期内只有一个实例。
 * 职责：
 *   1. 初始化 MultiDex（方法数超 64K 时必须）
 *   2. 提供全局 Context，避免内存泄漏
 *   3. 可在此初始化全局单例（如 OkHttpClient）
 */
public class NLKernelApp extends Application {

    /** 全局静态 Context，仅用于获取资源/系统服务，不用于 UI */
    private static NLKernelApp instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    /**
     * 在 attachBaseContext 阶段安装 MultiDex。
     * 此方法在 onCreate 之前调用，确保多 dex 文件正确加载。
     */
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);  // 必须在 super 之后立即调用
    }

    /**
     * 获取全局 Application 实例。
     * 用于在非 Activity 上下文中获取 Context。
     */
    public static NLKernelApp getInstance() {
        return instance;
    }
}
