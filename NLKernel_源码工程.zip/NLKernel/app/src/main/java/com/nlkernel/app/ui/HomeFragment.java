package com.nlkernel.app.ui;

import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.nlkernel.app.R;
import com.nlkernel.app.databinding.FragmentHomeBinding;
import com.nlkernel.app.util.DeviceInfoUtils;
import com.nlkernel.app.util.RootUtils;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * HomeFragment — 主页 Fragment
 *
 * 展示设备全量信息，分为四类卡片：
 *   ① Root 状态（彩色状态卡片，始终显示在最顶部）
 *   ② 设备基础信息（品牌/型号/Android 版本等）
 *   ③ 系统信息（内核版本/CPU 架构/SELinux）
 *   ④ 硬件信息（CPU/RAM）
 *   ⑤ 存储与电池
 *
 * 加载策略：
 *   - Phase 1（无 Root）：读取 Build.*、/proc/meminfo 等（同步，主线程，< 10ms）
 *   - Phase 2（需 Root）：异步执行 su 命令检测 Root/Magisk/SELinux 状态
 *   - 下拉刷新会强制重新执行两个 Phase
 */
public class HomeFragment extends Fragment {

    /** ViewBinding 实例（onDestroyView 时置 null 防止内存泄漏） */
    private FragmentHomeBinding binding;

    /** 单线程池，Root 命令顺序执行，防止并发冲突 */
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /** 主线程 Handler，子线程结果回调到 UI */
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    /** 首次加载标志，切换 Tab 时不重复加载 Phase 1 */
    private boolean deviceInfoLoaded = false;

    // ─────────────────────────────────────────────────────────────────────
    // Fragment 生命周期
    // ─────────────────────────────────────────────────────────────────────

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 下拉刷新配色（iOS 蓝 + 白色进度背景）
        binding.swipeRefresh.setColorSchemeColors(0xFF007AFF);
        binding.swipeRefresh.setProgressBackgroundColorSchemeColor(0xFFFFFFFF);

        // 下拉刷新回调：强制重新加载
        binding.swipeRefresh.setOnRefreshListener(() -> {
            deviceInfoLoaded = false;
            loadAllInfo();
        });

        // 首次进入时加载
        if (!deviceInfoLoaded) {
            loadAllInfo();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // 每次页面可见时重新检测 Root（用户可能在外部授权/撤销 Root）
        checkRootStatusAsync();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // 防止内存泄漏
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown(); // 关闭线程池
    }

    // ─────────────────────────────────────────────────────────────────────
    // 数据加载
    // ─────────────────────────────────────────────────────────────────────

    /**
     * 全量加载设备信息。
     */
    private void loadAllInfo() {
        if (getContext() == null || binding == null) return;

        // Phase 1：无 Root 基础信息（主线程直接读取，速度极快）
        Map<String, String> allInfo = DeviceInfoUtils.getAllDeviceInfo(requireContext());
        populateDeviceBasicCard(allInfo);
        populateSystemInfoCard(allInfo);
        populateHardwareCard(allInfo);
        populateStorageCard(allInfo);
        deviceInfoLoaded = true;

        // Phase 2：Root/Magisk/SELinux（异步子线程）
        checkRootStatusAsync();
        loadRootAdvancedInfoAsync();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Root 状态卡片
    // ─────────────────────────────────────────────────────────────────────

    /**
     * 异步检测 Root 状态，更新顶部彩色状态卡片。
     * 状态流转：橙色"检测中" → 绿色"已获取" 或 红色"未检测到"
     */
    private void checkRootStatusAsync() {
        if (binding == null) return;

        // 立即显示"检测中"占位状态（橙色）
        binding.tvRootStatusValue.setText(R.string.root_checking);
        binding.cardRootStatus.setCardBackgroundColor(0xFFFF9500);

        executor.execute(() -> {
            boolean rooted = RootUtils.isRooted();
            mainHandler.post(() -> {
                if (binding == null || !isAdded()) return;
                if (rooted) {
                    binding.tvRootStatusValue.setText(R.string.root_granted);
                    binding.cardRootStatus.setCardBackgroundColor(0xFF34C759); // 绿色
                } else {
                    binding.tvRootStatusValue.setText(R.string.root_denied);
                    binding.cardRootStatus.setCardBackgroundColor(0xFFFF3B30); // 红色
                }
                binding.swipeRefresh.setRefreshing(false);
            });
        });
    }

    /**
     * 异步加载需要 Root 的进阶信息：Magisk/KSU/APatch 版本 + SELinux 状态。
     */
    private void loadRootAdvancedInfoAsync() {
        if (!isAdded()) return;
        executor.execute(() -> {
            String magiskVer = RootUtils.getMagiskVersion();
            String selinux   = RootUtils.getSelinuxStatus();
            mainHandler.post(() -> {
                if (binding == null || !isAdded()) return;
                // Magisk 版本：显示在状态卡右侧角
                if (magiskVer != null && !magiskVer.isEmpty()) {
                    binding.tvMagiskVersion.setText(magiskVer);
                    binding.tvMagiskVersion.setVisibility(View.VISIBLE);
                }
                // SELinux 状态：更新系统信息卡中的对应行
                updateRowValue(binding.llSystemInfoRows, "SELinux", selinux, true);
            });
        });
    }

    // ─────────────────────────────────────────────────────────────────────
    // 各卡片填充
    // ─────────────────────────────────────────────────────────────────────

    /** 填充"设备信息"卡片 */
    private void populateDeviceBasicCard(Map<String, String> info) {
        if (binding == null) return;
        binding.llDeviceBasicRows.removeAllViews();

        // key 与 DeviceInfoUtils.getAllDeviceInfo() 中 info.put() 的 key 完全一致
        Map<String, String> rows = new LinkedHashMap<>();
        rows.put("品牌",       safeGet(info, "品牌"));
        rows.put("型号",       safeGet(info, "型号"));
        rows.put("设备代号",   safeGet(info, "设备代号"));
        rows.put("Android 版本", safeGet(info, "Android 版本"));
        rows.put("API 等级",   safeGet(info, "API 等级"));
        rows.put("系统版本号", safeGet(info, "系统版本号"));
        rows.put("安全补丁",   safeGet(info, "安全补丁"));
        fillRows(binding.llDeviceBasicRows, rows);
    }

    /** 填充"系统信息"卡片 */
    private void populateSystemInfoCard(Map<String, String> info) {
        if (binding == null) return;
        binding.llSystemInfoRows.removeAllViews();

        Map<String, String> rows = new LinkedHashMap<>();
        rows.put("内核版本",   safeGet(info, "内核版本"));
        rows.put("处理器架构", safeGet(info, "处理器架构"));
        rows.put("SELinux",   "检测中…");   // Phase 2 异步更新
        fillRows(binding.llSystemInfoRows, rows);
    }

    /** 填充"硬件信息"卡片 */
    private void populateHardwareCard(Map<String, String> info) {
        if (binding == null) return;
        binding.llHardwareInfoRows.removeAllViews();

        Map<String, String> rows = new LinkedHashMap<>();
        rows.put("CPU 型号",  safeGet(info, "CPU 型号"));
        rows.put("CPU 核心数", safeGet(info, "CPU 核心数"));
        rows.put("运行内存",   safeGet(info, "运行内存"));
        fillRows(binding.llHardwareInfoRows, rows);
    }

    /** 填充"存储与电池"卡片 */
    private void populateStorageCard(Map<String, String> info) {
        if (binding == null) return;
        binding.llStorageInfoRows.removeAllViews();

        Map<String, String> rows = new LinkedHashMap<>();
        rows.put("存储空间", safeGet(info, "存储空间"));
        rows.put("电池电量", safeGet(info, "电池电量"));
        fillRows(binding.llStorageInfoRows, rows);
    }

    // ─────────────────────────────────────────────────────────────────────
    // 工具方法
    // ─────────────────────────────────────────────────────────────────────

    /**
     * 安全从 Map 取值，若为 null 则返回 "—"。
     */
    private String safeGet(Map<String, String> map, String key) {
        String v = map.get(key);
        return (v != null && !v.isEmpty()) ? v : "—";
    }

    /**
     * 将有序 Map 渲染为 LinearLayout 中的 key-value 行。
     * 每两行之间插入 0.5dp 分隔线，最后一行不加。
     */
    private void fillRows(LinearLayout container, Map<String, String> rows) {
        if (getContext() == null || container == null) return;
        int total = rows.size();
        int index = 0;
        for (Map.Entry<String, String> entry : rows.entrySet()) {
            addInfoRow(container, entry.getKey(), entry.getValue());
            if (index < total - 1) {
                addDivider(container);
            }
            index++;
        }
    }

    /**
     * 动态创建一行信息（标签 + 值），添加到容器。
     * 给行 View 打上 label Tag，便于后续通过 updateRowValue() 定向更新。
     */
    private void addInfoRow(LinearLayout container, String label, String value) {
        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dpToPx(9), 0, dpToPx(9));
        row.setTag(label);   // 用 label 作为 Tag，供 updateRowValue 查找

        // 标签（左侧，42% 宽，iOS 次级灰）
        TextView tvLabel = new TextView(requireContext());
        tvLabel.setText(label);
        tvLabel.setTextSize(13f);
        tvLabel.setTextColor(0xFF8E8E93);
        tvLabel.setMaxLines(1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.42f);
        tvLabel.setLayoutParams(lp);

        // 值（右侧，58% 宽，iOS 主黑，加粗，右对齐）
        TextView tvValue = new TextView(requireContext());
        tvValue.setText(value);
        tvValue.setTextSize(13f);
        tvValue.setTextColor(0xFF1C1C1E);
        tvValue.setTypeface(null, Typeface.BOLD);
        tvValue.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
        tvValue.setMaxLines(2);
        tvValue.setTag("value");  // 标记为值 TextView
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.58f);
        tvValue.setLayoutParams(vp);

        row.addView(tvLabel);
        row.addView(tvValue);
        container.addView(row);
    }

    /**
     * 在容器中按 label Tag 定向更新某行的值文字。
     *
     * @param container  父容器
     * @param label      目标行的标签（必须与 addInfoRow 时的 label 一致）
     * @param newValue   新值
     * @param colorCode  是否根据值内容着色（用于 SELinux 状态）
     */
    private void updateRowValue(LinearLayout container, String label,
                                String newValue, boolean colorCode) {
        if (container == null || newValue == null) return;
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (label.equals(child.getTag()) && child instanceof LinearLayout) {
                LinearLayout row = (LinearLayout) child;
                for (int j = 0; j < row.getChildCount(); j++) {
                    View v = row.getChildAt(j);
                    if ("value".equals(v.getTag()) && v instanceof TextView) {
                        TextView tv = (TextView) v;
                        tv.setText(newValue);
                        if (colorCode) {
                            if ("Permissive".equalsIgnoreCase(newValue)) {
                                tv.setTextColor(0xFF34C759); // 绿：宽松
                            } else if ("Enforcing".equalsIgnoreCase(newValue)) {
                                tv.setTextColor(0xFFFF9500); // 橙：强制
                            } else {
                                tv.setTextColor(0xFF1C1C1E); // 默认黑
                            }
                        }
                        break;
                    }
                }
                break;
            }
        }
    }

    /** 添加 1px 水平分隔线 */
    private void addDivider(LinearLayout container) {
        View divider = new View(requireContext());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        divider.setLayoutParams(p);
        divider.setBackgroundColor(0x18000000); // ~10% 黑色透明
        container.addView(divider);
    }

    /** dp 转 px（适配多密度屏幕） */
    private int dpToPx(int dp) {
        float density = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
