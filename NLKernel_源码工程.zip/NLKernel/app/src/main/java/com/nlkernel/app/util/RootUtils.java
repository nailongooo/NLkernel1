package com.nlkernel.app.util;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/**
 * RootUtils — Root 权限工具类
 *
 * 封装所有需要 Root 权限的底层操作：
 *   - 检测设备是否已 Root
 *   - 以 su 运行 shell 命令
 *   - 创建目录、设置权限、执行脚本
 *   - 查询 Magisk、SELinux 状态
 *
 * 设计原则：
 *   所有方法均为同步（阻塞），调用方必须在子线程执行，
 *   不得在主线程（UI 线程）调用，否则会导致 ANR。
 *
 * 兼容性：
 *   通过 "su" 命令与 Magisk/KernelSU/APatch 等常见 Root 方案交互，
 *   不依赖特定 Root 实现，适配 MIUI/ColorOS/OneUI 等主流 ROM。
 */
public class RootUtils {

    private static final String TAG = "NLKernel_Root";

    /**
     * 目标脚本存储目录（/data/adb 是 Magisk 的专属目录，Root 后可写）
     */
    public static final String SCRIPT_DIR = "/data/adb/NLkernel";

    /**
     * 命令执行超时时间（秒）
     * 某些复杂脚本可能耗时较长，设为 120 秒防止死锁
     */
    private static final int TIMEOUT_SECONDS = 120;

    // ====================================================================
    // Root 检测
    // ====================================================================

    /**
     * 检测设备是否已获取 Root 权限。
     *
     * 策略（按优先级）：
     *   1. 尝试执行 "su -c id"，若返回含 "uid=0" 则确认 Root 成功
     *   2. 失败则检查常见 su 二进制路径是否存在
     *
     * @return true = 已 Root，false = 未 Root 或权限被拒绝
     */
    public static boolean isRooted() {
        // 方法一：实际执行 su 命令验证（最可靠）
        try {
            CommandResult result = executeRootCommand("id");
            if (result.success && result.output.contains("uid=0")) {
                Log.d(TAG, "Root 验证成功: " + result.output);
                return true;
            }
        } catch (Exception e) {
            Log.w(TAG, "su 命令执行失败: " + e.getMessage());
        }

        // 方法二：检查 su 二进制文件是否存在（备用方案）
        String[] suPaths = {
            "/sbin/su", "/su/bin/su", "/system/bin/su",
            "/system/xbin/su", "/data/local/xbin/su",
            "/data/local/bin/su", "/system/sd/xbin/su"
        };
        for (String path : suPaths) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"ls", path});
                int exitCode = p.waitFor();
                if (exitCode == 0) {
                    Log.d(TAG, "找到 su 二进制: " + path);
                    return true;
                }
            } catch (Exception ignored) {}
        }

        Log.d(TAG, "未检测到 Root 权限");
        return false;
    }

    // ====================================================================
    // 命令执行
    // ====================================================================

    /**
     * 以 Root 权限执行单行 shell 命令。
     *
     * 原理：
     *   通过 Runtime.exec("su") 启动 su 进程，
     *   向其 stdin 写入命令，读取 stdout/stderr 结果。
     *
     * @param command 要执行的 shell 命令，例如 "chmod 777 /data/adb/NLkernel/test.sh"
     * @return CommandResult 包含执行结果和输出内容
     */
    public static CommandResult executeRootCommand(String command) {
        StringBuilder outputBuilder = new StringBuilder();
        StringBuilder errorBuilder = new StringBuilder();
        Process process = null;
        DataOutputStream stdin = null;

        try {
            Log.d(TAG, "执行 Root 命令: " + command);

            // 启动 su 进程（不同 Root 方案的 su 路径可能不同，但 "su" 通常在 PATH 中）
            process = Runtime.getRuntime().exec("su");
            stdin = new DataOutputStream(process.getOutputStream());

            // 向 su 的标准输入写入命令
            stdin.writeBytes(command + "\n");
            // exit 命令确保 su 进程正常退出，否则 waitFor 可能永久阻塞
            stdin.writeBytes("exit\n");
            stdin.flush();

            // 读取标准输出（非阻塞：先等进程结束再读，避免缓冲区满导致死锁）
            // 注意：对于输出量很大的命令，应改用独立线程读取
            BufferedReader stdoutReader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
            BufferedReader stderrReader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()));

            // 等待进程完成（带超时防止永久阻塞）
            boolean finished = process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            if (!finished) {
                Log.w(TAG, "命令执行超时（" + TIMEOUT_SECONDS + "s），强制终止");
                process.destroy();
                return new CommandResult(false, "", "执行超时");
            }

            // 读取输出（进程结束后读取，避免阻塞）
            String line;
            while ((line = stdoutReader.readLine()) != null) {
                outputBuilder.append(line).append("\n");
            }
            while ((line = stderrReader.readLine()) != null) {
                errorBuilder.append(line).append("\n");
            }

            int exitCode = process.exitValue();
            boolean success = (exitCode == 0);
            String output = outputBuilder.toString().trim();
            String error = errorBuilder.toString().trim();

            Log.d(TAG, "命令返回码: " + exitCode + ", 输出: " + output);
            if (!error.isEmpty()) {
                Log.w(TAG, "命令错误输出: " + error);
            }

            return new CommandResult(success, output, error);

        } catch (IOException e) {
            Log.e(TAG, "IO 错误（可能 su 不存在或权限被拒绝）: " + e.getMessage());
            return new CommandResult(false, "", "IO错误: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            Log.e(TAG, "线程中断: " + e.getMessage());
            return new CommandResult(false, "", "中断错误");
        } finally {
            // 确保资源正确关闭
            if (stdin != null) {
                try { stdin.close(); } catch (IOException ignored) {}
            }
            if (process != null) {
                process.destroy();
            }
        }
    }

    /**
     * 执行多行 shell 命令（批量执行，一次 su 进程）。
     * 比多次调用 executeRootCommand 效率更高（避免重复弹出 Root 授权弹窗）。
     *
     * @param commands 命令数组
     * @return 最后一条命令的结果
     */
    public static CommandResult executeRootCommands(String[] commands) {
        StringBuilder allCommands = new StringBuilder();
        for (String cmd : commands) {
            allCommands.append(cmd).append("\n");
        }
        // 将多条命令合并为单行脚本（用 && 连接，任一失败则停止）
        String combined = String.join(" && ", commands);
        return executeRootCommand(combined);
    }

    // ====================================================================
    // 目录管理
    // ====================================================================

    /**
     * 确保 /data/adb/NLkernel 目录存在并可写。
     * 若不存在则创建，并设置合适的权限（755：只有 root 可写，其他可读执行）。
     *
     * @return true = 目录就绪，false = 创建失败
     */
    public static boolean ensureScriptDirectory() {
        // 先检查目录是否存在
        CommandResult checkResult = executeRootCommand(
                "[ -d " + SCRIPT_DIR + " ] && echo EXISTS || echo NOT_EXISTS"
        );

        if (checkResult.output.contains("NOT_EXISTS")) {
            Log.i(TAG, "目录不存在，创建: " + SCRIPT_DIR);
            // 创建目录（-p 递归创建父目录）
            CommandResult mkdirResult = executeRootCommand(
                    "mkdir -p " + SCRIPT_DIR + " && chmod 755 " + SCRIPT_DIR
            );
            if (!mkdirResult.success) {
                Log.e(TAG, "创建目录失败: " + mkdirResult.error);
                return false;
            }
        }

        Log.d(TAG, "脚本目录就绪: " + SCRIPT_DIR);
        return true;
    }

    // ====================================================================
    // 脚本执行核心流程
    // ====================================================================

    /**
     * 将已下载到临时位置的脚本文件移动到目标目录，设置权限，并执行。
     *
     * 完整流程：
     *   1. 确保目标目录存在
     *   2. 将临时文件移动到 /data/adb/NLkernel/<filename>
     *   3. chmod 777（赋予全权限，确保脚本可执行）
     *   4. 执行脚本（sh /data/adb/NLkernel/<filename>）
     *   5. 返回执行结果
     *
     * @param tempFilePath 已下载脚本的临时文件路径（通常在 /sdcard/Android/data/ 下）
     * @param filename     脚本文件名（如 "boost.sh"）
     * @return ExecuteResult 包含是否成功和输出内容
     */
    public static ExecuteResult moveAndExecuteScript(String tempFilePath, String filename) {
        Log.i(TAG, "开始处理脚本: " + filename + "，临时路径: " + tempFilePath);

        // 步骤 1：确保目标目录存在
        if (!ensureScriptDirectory()) {
            return new ExecuteResult(false, "", "无法创建目录 " + SCRIPT_DIR);
        }

        String targetPath = SCRIPT_DIR + "/" + filename;

        // 步骤 2：将文件复制到目标目录（用 cp 而非 mv，避免跨文件系统问题）
        // /sdcard 是 vfat/fuse，/data/adb 是 ext4，mv 跨文件系统会失败
        CommandResult copyResult = executeRootCommand(
                "cp \"" + tempFilePath + "\" \"" + targetPath + "\""
        );
        if (!copyResult.success) {
            Log.e(TAG, "文件复制失败: " + copyResult.error);
            // 尝试 mv 作为备选
            copyResult = executeRootCommand(
                    "mv \"" + tempFilePath + "\" \"" + targetPath + "\""
            );
            if (!copyResult.success) {
                return new ExecuteResult(false, "", "文件复制失败: " + copyResult.error);
            }
        }
        Log.i(TAG, "文件复制到: " + targetPath);

        // 步骤 3：赋予 777 权限（读/写/执行 对所有用户）
        // 这是脚本能被 sh 执行的前提
        CommandResult chmodResult = executeRootCommand(
                "chmod 777 \"" + targetPath + "\""
        );
        if (!chmodResult.success) {
            Log.w(TAG, "chmod 777 失败（将尝试 755）: " + chmodResult.error);
            // 备选：chmod 755（只有 root 可写）
            executeRootCommand("chmod 755 \"" + targetPath + "\"");
        }
        Log.i(TAG, "权限设置完成 (chmod 777): " + targetPath);

        // 步骤 4：执行脚本
        // 使用 sh 而非直接执行，确保脚本内 #!/bin/sh shebang 被正确处理
        // 2>&1 将 stderr 合并到 stdout，方便捕获所有输出
        CommandResult execResult = executeRootCommand(
                "sh \"" + targetPath + "\" 2>&1"
        );
        Log.i(TAG, "脚本执行完毕，成功: " + execResult.success);

        return new ExecuteResult(
                execResult.success,
                execResult.output,
                execResult.error
        );
    }

    // ====================================================================
    // 系统信息查询（需要 Root 的部分）
    // ====================================================================

    /**
     * 获取 Magisk 版本号。
     * 通过调用 magisk --version 命令获取。
     *
     * @return 版本字符串（如 "27000"），未安装返回 null
     */
    public static String getMagiskVersion() {
        CommandResult result = executeRootCommand("magisk --version 2>/dev/null");
        if (result.success && !result.output.isEmpty()) {
            return result.output.trim();
        }
        // 尝试 KernelSU
        CommandResult ksuResult = executeRootCommand("ksud --version 2>/dev/null");
        if (ksuResult.success && !ksuResult.output.isEmpty()) {
            return "KernelSU " + ksuResult.output.trim();
        }
        // 尝试 APatch
        CommandResult apResult = executeRootCommand("apd --version 2>/dev/null");
        if (apResult.success && !apResult.output.isEmpty()) {
            return "APatch " + apResult.output.trim();
        }
        return null;
    }

    /**
     * 获取 SELinux 状态。
     *
     * @return "Enforcing" / "Permissive" / "Disabled" / "Unknown"
     */
    public static String getSelinuxStatus() {
        CommandResult result = executeRootCommand("getenforce 2>/dev/null");
        if (result.success && !result.output.isEmpty()) {
            return result.output.trim();
        }
        // 备选：读取 selinux 文件
        CommandResult catResult = executeRootCommand(
                "cat /sys/fs/selinux/enforce 2>/dev/null"
        );
        if (catResult.success) {
            return catResult.output.trim().equals("1") ? "Enforcing" : "Permissive";
        }
        return "Unknown";
    }

    /**
     * 获取 Linux 内核版本（从 /proc/version 读取完整信息）。
     *
     * @return 内核版本字符串，如 "5.15.104-android13-8"
     */
    public static String getKernelVersionFull() {
        CommandResult result = executeRootCommand("cat /proc/version");
        if (result.success && !result.output.isEmpty()) {
            return result.output.trim();
        }
        return android.os.Build.VERSION.INCREMENTAL; // 回退到 Build 信息
    }

    // ====================================================================
    // 内部数据类
    // ====================================================================

    /**
     * shell 命令执行结果封装类
     */
    public static class CommandResult {
        /** 命令是否成功（退出码为 0） */
        public final boolean success;
        /** 标准输出内容 */
        public final String output;
        /** 标准错误内容 */
        public final String error;

        public CommandResult(boolean success, String output, String error) {
            this.success = success;
            this.output = output != null ? output : "";
            this.error = error != null ? error : "";
        }
    }

    /**
     * 脚本执行结果封装类
     */
    public static class ExecuteResult {
        public final boolean success;
        public final String output;
        public final String error;

        public ExecuteResult(boolean success, String output, String error) {
            this.success = success;
            this.output = output != null ? output : "";
            this.error = error != null ? error : "";
        }
    }
}
