package com.nlkernel.app.util;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * DeviceInfoUtils — 设备信息收集工具类
 *
 * 汇总手机的各项硬件和软件信息，用于主页展示。
 * 所有方法均通过安全 API 获取信息（无需 Root），
 * 部分进阶信息（SELinux、Magisk）通过 RootUtils 补充。
 *
 * 兼容性注意：
 *   - 部分厂商（MIUI、OneUI）对 /proc 文件访问有限制，
 *     已添加多路回退机制
 *   - Build.XXX 字段在 API 28+ 可能因隐私政策被限制，
 *     已适配返回默认值的情况
 */
public class DeviceInfoUtils {

    private static final String TAG = "NLKernel_Device";

    /**
     * 收集并返回所有设备信息，格式为有序 Map（保证显示顺序）。
     *
     * @param context Android 上下文
     * @return LinkedHashMap，key=信息标签，value=信息内容
     */
    public static Map<String, String> getAllDeviceInfo(Context context) {
        // 使用 LinkedHashMap 保证插入顺序（即显示顺序）
        Map<String, String> info = new LinkedHashMap<>();

        // ---- 设备基本信息 ----
        info.put("品牌", getBrand());
        info.put("型号", getModel());
        info.put("设备代号", getDevice());

        // ---- 系统信息 ----
        info.put("Android 版本", getAndroidVersion());
        info.put("API 等级", String.valueOf(Build.VERSION.SDK_INT));
        info.put("系统版本号", getBuildId());
        info.put("安全补丁", getSecurityPatch());

        // ---- 内核信息 ----
        info.put("内核版本", getKernelVersion());
        info.put("处理器架构", getCpuAbi());

        // ---- 硬件信息 ----
        info.put("CPU 型号", getCpuModel());
        info.put("CPU 核心数", getCpuCores());
        info.put("运行内存", getRamInfo(context));
        info.put("存储空间", getStorageInfo());

        // ---- 电池信息 ----
        info.put("电池电量", getBatteryLevel(context));

        return info;
    }

    // ====================================================================
    // 设备基本信息
    // ====================================================================

    /** 品牌，如 "Xiaomi", "Samsung", "HUAWEI" */
    public static String getBrand() {
        String brand = Build.BRAND;
        // 首字母大写处理
        if (brand != null && !brand.isEmpty()) {
            return Character.toUpperCase(brand.charAt(0)) + brand.substring(1);
        }
        return "Unknown";
    }

    /** 商品名（面向用户的型号），如 "Redmi Note 12" */
    public static String getModel() {
        return Build.MODEL != null ? Build.MODEL : "Unknown";
    }

    /** 设备代号（工程代号），如 "tapas" */
    public static String getDevice() {
        return Build.DEVICE != null ? Build.DEVICE : "Unknown";
    }

    // ====================================================================
    // 系统信息
    // ====================================================================

    /** Android 版本字符串，如 "14" 或 "Android 14" */
    public static String getAndroidVersion() {
        return "Android " + Build.VERSION.RELEASE
               + " (" + Build.VERSION.CODENAME + ")";
    }

    /** Build ID（系统版本号），如 "UP1A.231005.007" */
    public static String getBuildId() {
        return Build.ID != null ? Build.ID : "Unknown";
    }

    /** 安全补丁日期，API 23+，如 "2024-01-05" */
    public static String getSecurityPatch() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String patch = Build.VERSION.SECURITY_PATCH;
            return (patch != null && !patch.isEmpty()) ? patch : "N/A";
        }
        return "N/A (API < 23)";
    }

    // ====================================================================
    // 内核信息
    // ====================================================================

    /**
     * Linux 内核版本号。
     * 读取 /proc/version 并提取核心版本号部分。
     * 回退方案：System.getProperty("os.version")
     *
     * @return 如 "5.15.104-android13"
     */
    public static String getKernelVersion() {
        // 方法一：读取 /proc/version（最可靠）
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/version"))) {
            String line = reader.readLine();
            if (line != null) {
                // /proc/version 格式：Linux version X.Y.Z-xxx (compiler info) #build ...
                // 提取 "Linux version " 后的第一个空格前内容
                String[] parts = line.split("\\s+");
                if (parts.length >= 3) {
                    return parts[2]; // index 2 是版本号
                }
                return line.substring(0, Math.min(line.length(), 60));
            }
        } catch (IOException e) {
            Log.w(TAG, "读取 /proc/version 失败（部分 ROM 限制访问）: " + e.getMessage());
        }

        // 方法二：系统属性（备用）
        String osVersion = System.getProperty("os.version");
        return (osVersion != null && !osVersion.isEmpty()) ? osVersion : "Unknown";
    }

    /**
     * 获取主 CPU ABI（指令集架构）。
     *
     * @return 如 "arm64-v8a", "armeabi-v7a", "x86_64"
     */
    public static String getCpuAbi() {
        String[] abis = Build.SUPPORTED_ABIS;
        if (abis != null && abis.length > 0) {
            // 返回主 ABI（第一个，优先级最高）
            return abis[0];
        }
        return "Unknown";
    }

    // ====================================================================
    // CPU 信息
    // ====================================================================

    /**
     * 从 /proc/cpuinfo 读取 CPU 型号。
     * 不同架构的字段名不同（arm64 用 "Hardware" 或 "model name"，x86 用 "model name"）
     *
     * @return CPU 型号字符串，如 "Qualcomm Snapdragon 8 Gen 2"
     */
    public static String getCpuModel() {
        // 尝试读取 /proc/cpuinfo
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/cpuinfo"))) {
            String line;
            String hardware = null;
            String modelName = null;

            while ((line = reader.readLine()) != null) {
                // arm64 设备通常有 "Hardware" 字段
                if (line.startsWith("Hardware") && line.contains(":")) {
                    hardware = line.split(":", 2)[1].trim();
                }
                // x86 和部分 arm 设备有 "model name" 字段
                if (line.startsWith("model name") && line.contains(":") && modelName == null) {
                    modelName = line.split(":", 2)[1].trim();
                }
            }

            // 优先返回 Hardware，其次 model name
            if (hardware != null && !hardware.isEmpty()) return hardware;
            if (modelName != null && !modelName.isEmpty()) return modelName;

        } catch (IOException e) {
            Log.w(TAG, "读取 /proc/cpuinfo 失败: " + e.getMessage());
        }

        // 回退：通过 SOC 信息（Android 12+）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Build.SOC_MANUFACTURER 和 Build.SOC_MODEL 在 API 31+ 可用
            try {
                String socManufacturer = Build.SOC_MANUFACTURER;
                String socModel = Build.SOC_MODEL;
                if (socManufacturer != null && socModel != null) {
                    return socManufacturer + " " + socModel;
                }
            } catch (Exception ignored) {}
        }

        return "Unknown CPU";
    }

    /**
     * 获取 CPU 核心数。
     *
     * @return 如 "8 核" 或 "Unknown"
     */
    public static String getCpuCores() {
        int cores = Runtime.getRuntime().availableProcessors();
        if (cores > 0) {
            return cores + " 核";
        }
        // 备选：读取 /sys/devices/system/cpu/present
        try (BufferedReader reader = new BufferedReader(
                new FileReader("/sys/devices/system/cpu/present"))) {
            String line = reader.readLine();
            if (line != null && line.contains("-")) {
                // 格式 "0-7" 表示 8 核
                int maxCore = Integer.parseInt(line.split("-")[1].trim()) + 1;
                return maxCore + " 核";
            }
        } catch (Exception ignored) {}
        return "Unknown";
    }

    // ====================================================================
    // 内存信息
    // ====================================================================

    /**
     * 获取运行内存信息（总量 / 可用）。
     *
     * @param context Android 上下文（需要 ActivityManager）
     * @return 如 "8 GB (可用: 3.2 GB)"
     */
    public static String getRamInfo(Context context) {
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return "Unknown";

            ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(memInfo);

            long totalMb = memInfo.totalMem / (1024 * 1024);
            long availMb = memInfo.availMem / (1024 * 1024);

            // 格式化显示（超过 1024MB 显示 GB）
            String totalStr = formatMemory(memInfo.totalMem);
            String availStr = formatMemory(memInfo.availMem);

            return totalStr + " (可用: " + availStr + ")";

        } catch (Exception e) {
            Log.w(TAG, "获取内存信息失败: " + e.getMessage());
            return "Unknown";
        }
    }

    /** 格式化字节数为可读内存大小 */
    private static String formatMemory(long bytes) {
        double gb = bytes / (1024.0 * 1024 * 1024);
        if (gb >= 1.0) {
            return String.format("%.1f GB", gb);
        }
        double mb = bytes / (1024.0 * 1024);
        return String.format("%.0f MB", mb);
    }

    // ====================================================================
    // 存储信息
    // ====================================================================

    /**
     * 获取内部存储空间信息（总量 / 可用）。
     * 读取 /data 分区的统计信息。
     *
     * @return 如 "128 GB (可用: 64.3 GB)"
     */
    public static String getStorageInfo() {
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            long blockSize = stat.getBlockSizeLong();
            long totalBlocks = stat.getBlockCountLong();
            long availableBlocks = stat.getAvailableBlocksLong();

            long total = totalBlocks * blockSize;
            long available = availableBlocks * blockSize;

            return formatStorage(total) + " (可用: " + formatStorage(available) + ")";

        } catch (Exception e) {
            Log.w(TAG, "获取存储信息失败: " + e.getMessage());
            return "Unknown";
        }
    }

    /** 格式化存储大小 */
    private static String formatStorage(long bytes) {
        double gb = bytes / (1024.0 * 1024 * 1024);
        if (gb >= 1.0) return String.format("%.1f GB", gb);
        double mb = bytes / (1024.0 * 1024);
        return String.format("%.0f MB", mb);
    }

    // ====================================================================
    // 电池信息
    // ====================================================================

    /**
     * 获取电池电量和充电状态。
     * 通过注册 ACTION_BATTERY_CHANGED 广播获取（无需权限）。
     *
     * @param context Android 上下文
     * @return 如 "85% (充电中)" 或 "72% (放电)"
     */
    public static String getBatteryLevel(Context context) {
        try {
            // 电池广播是粘性广播，传 null receiver 可同步获取最新数据
            IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = context.registerReceiver(null, filter);

            if (batteryStatus == null) return "Unknown";

            // 电量百分比
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int batteryPct = (level != -1 && scale != -1)
                    ? (int) (level * 100.0f / scale)
                    : -1;

            // 充电状态
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String chargeStatus;
            switch (status) {
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    chargeStatus = "充电中";
                    break;
                case BatteryManager.BATTERY_STATUS_FULL:
                    chargeStatus = "已充满";
                    break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    chargeStatus = "放电";
                    break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    chargeStatus = "未充电";
                    break;
                default:
                    chargeStatus = "未知";
            }

            return batteryPct + "% (" + chargeStatus + ")";

        } catch (Exception e) {
            Log.w(TAG, "获取电池信息失败: " + e.getMessage());
            return "Unknown";
        }
    }
}
